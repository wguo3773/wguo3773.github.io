#' Compare designs across dose-toxicity scenarios
#'
#' Plot the true dose-toxicity curves, colored by the difference between two
#' methods' scenario-level operating characteristics. The vertical axis is
#' untreated DLT probability, not the comparison metric.
#' @param x Result from simulate_random_scenarios(), including scenarios,
#'   settings and summary, or a list with those elements.
#' @param method,comparator Method names present in x$summary.
#' @param metric One of accuracy_pct, actual_dlts, mean_n, above_mtd_pct,
#'   or duration_months. Higher accuracy is better; lower is better otherwise.
#' @param relative_gap Difference threshold, default 0.10. Divide the absolute
#'   difference by the larger absolute estimate; two zero values have gap zero.
#' @param target Horizontal reference for the target DLT probability.
#' @param colors Colors for method better, comparator better, and below threshold.
#' @param ... Additional arguments passed to graphics::plot.default().
#' @return Invisibly, the per-scenario comparison data, including direction,
#'   relative_gap and color. Curves are grouped by MTD and gap settings when
#'   available. Colors are descriptive comparisons, not significance tests.
#' @export
#' @examples
#' z <- simulate_random_scenarios(nscenarios=3, nsim=10,
#'   method=c("combined","tite_boin"), seed=42)
#' plot_spaghetti(z, method="combined", comparator="tite_boin")
plot_spaghetti <- function(x, method="combined", comparator="tite_boin",
                            metric="accuracy_pct", relative_gap=.10,
                            target=if(!is.null(x$config)) x$config$target else .25,
                            colors=c("#2563B5","#BC4E50","#7F8C8D"), ...) {
  metrics<-c("accuracy_pct","actual_dlts","mean_n","above_mtd_pct","duration_months")
  if(!is.list(x) || !is.matrix(x$scenarios) || !is.numeric(x$scenarios) ||
     !is.data.frame(x$summary) || !is.data.frame(x$settings))
    stop("Supply a random-scenario result with scenarios, summary and settings")
  if(length(method)!=1L || length(comparator)!=1L || identical(method,comparator) ||
     !all(c(method,comparator)%in%x$summary$method)) stop("Choose two distinct methods in the result")
  if(length(metric)!=1L || !metric%in%metrics || !metric%in%names(x$summary)) stop("Unsupported metric")
  if(length(relative_gap)!=1L || !is.finite(relative_gap) || relative_gap<0 || relative_gap>1)
    stop("relative_gap must be between zero and one")
  if(length(target)!=1L || !is.finite(target) || target<=0 || target>=1) stop("Invalid target")
  if(length(colors)!=3L || anyNA(colors)) stop("Supply three colors")
  grDevices::col2rgb(colors)
  a<-x$summary[x$summary$method==method,c("scenario",metric)]
  b<-x$summary[x$summary$method==comparator,c("scenario",metric)]
  if(anyDuplicated(a$scenario) || anyDuplicated(b$scenario)) stop("Duplicate scenario-method estimates")
  names(a)[2]<-"method_value";names(b)[2]<-"comparator_value"
  d<-merge(a,b,by="scenario",all=TRUE)
  if(any(!is.finite(d$method_value)) || any(!is.finite(d$comparator_value)))
    stop("Both methods need finite estimates for every scenario; duration is unavailable for complete-follow-up designs")
  if(any(!is.finite(x$scenarios)) || any(x$scenarios<=0 | x$scenarios>=1) ||
     any(apply(x$scenarios,1,is.unsorted))) stop("Invalid scenario risk matrix")
  if(any(d$scenario!=floor(d$scenario) | d$scenario<1 | d$scenario>nrow(x$scenarios)) ||
     !setequal(d$scenario,seq_len(nrow(x$scenarios)))) stop("Scenario indices must match the risk matrix")
  settings<-x$settings
  if(!"scenario"%in%names(settings)) settings$scenario<-seq_len(nrow(settings))
  if(anyDuplicated(settings$scenario) || !setequal(settings$scenario,d$scenario)) stop("Settings must match every scenario once")
  grouping<-intersect(c("mtd","lower_gap","upper_gap"),names(settings))
  d<-merge(d,settings[c("scenario",grouping)],by="scenario",sort=TRUE)
  den<-pmax(abs(d$method_value),abs(d$comparator_value))
  d$relative_gap<-ifelse(den==0,0,abs(d$method_value-d$comparator_value)/den)
  gain<-(d$method_value-d$comparator_value)*if(metric=="accuracy_pct") 1 else -1
  d$direction<-ifelse(gain!=0 & d$relative_gap>=relative_gap,
    ifelse(gain>0,"method_better","comparator_better"),"below_threshold")
  d$color<-colors[match(d$direction,c("method_better","comparator_better","below_threshold"))]
  key<-if(length(grouping)) interaction(d[grouping],drop=TRUE,lex.order=TRUE) else factor(rep("All",nrow(d)))
  panels<-split(d,key)
  old<-graphics::par(no.readonly=TRUE);on.exit(graphics::par(old),add=TRUE)
  ncols<-min(2L,length(panels));nrows<-ceiling(length(panels)/ncols)
  graphics::par(mfrow=c(nrows,ncols),mar=c(4.2,4,3.5,1),oma=c(3,0,2,0),mgp=c(2.3,.7,0))
  for(p in panels) {
    title<-if(length(grouping)) paste(vapply(grouping,function(nm)
      paste(if(nm=="mtd") "MTD" else gsub("_"," ",nm),p[[nm]][1]),character(1)),collapse=" | ") else "All scenarios"
    k<-ncol(x$scenarios)
    graphics::plot(seq_len(k),rep(NA_real_,k),type="n",ylim=c(0,1),xaxt="n",
      xlab="Dose",ylab="True untreated DLT probability",main=title,...)
    graphics::axis(1,seq_len(k),paste0("D",seq_len(k)))
    graphics::abline(h=target,col="#B3B9BA",lty=3)
    for(i in seq_len(nrow(p))) graphics::lines(seq_len(k),x$scenarios[p$scenario[i],],col=grDevices::adjustcolor(p$color[i],alpha.f=.70),lwd=1.2)
    counts<-table(factor(p$direction,levels=c("method_better","comparator_better","below_threshold")))
    graphics::mtext(paste("Method",counts[1]," / comparator",counts[2]," / below threshold",counts[3]),side=3,line=.3,cex=.7)
  }
  graphics::mtext(paste(method,"vs",comparator,"|",gsub("_"," ",metric)),outer=TRUE,side=3,cex=.95,font=2)
  graphics::mtext(paste0("Blue: method better | Red: comparator better | Gray: gap < ",100*relative_gap,"%. Descriptive, not significance tests."),outer=TRUE,side=1,cex=.7)
  invisible(d)
}
